function siglo(year) {
    return Math.ceil(year / 100);
}

function primerAnho(century) {
    return (century - 1) * 100 + 1;
}

function conversionALas8AM(cantidadMonedaLocal) {
    return cantidadMonedaLocal;
}

function conversionAlMediodia(cantidadMonedaLocal) {
    return cantidadMonedaLocal * 0.9;
}

function conversionMedidas(metros) {
    let pies = metros * 3.28084;
    let pulgadas = pies * 12;
    let centimetros = metros * 100;

    document.getElementById("resultado").innerHTML = metros + " metros equivalen a:<br>" +
        pies + " pies<br>" +
        pulgadas + " pulgadas<br>" +
        centimetros + " centímetros";
}

function procesarDatos() {
    let year = parseInt(document.getElementById("year").value);
    let cantidadMonedaLocal = parseFloat(document.getElementById("cantidadMoneda").value);
    let metros = parseFloat(document.getElementById("metros").value);

    let century = siglo(year);
    let primerAnhoSiglo = primerAnho(century);
    let cantidad8AM = conversionALas8AM(cantidadMonedaLocal);
    let cantidadMediodia = conversionAlMediodia(cantidadMonedaLocal);

    document.getElementById("sigloResultado").innerHTML = "El año " + year + " pertenece al siglo " + century + " y su primer año es " + primerAnhoSiglo;
    document.getElementById("conversion8AM").innerHTML = "Cantidad de dinero a las 8:00 a.m.: " + cantidad8AM;
    document.getElementById("conversionMediodia").innerHTML = "Cantidad de dinero al mediodía: " + cantidadMediodia;
    conversionMedidas(metros);
}
